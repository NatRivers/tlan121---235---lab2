# CS235FlixSkeleton
The skeleton python project for the 2020 S2 CompSci 235 practical assignment CS235Flix. I use Python 3.7 for the assignment and get the same .env file like the covid web. 

Flask run -> run it in the pycharm terminal as usual, right click on wsgi.py and run.
