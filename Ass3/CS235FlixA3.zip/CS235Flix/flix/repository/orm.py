from sqlalchemy import (
    Table, MetaData, Column, Integer, String, Date, DateTime,
    ForeignKey
)
from sqlalchemy.orm import mapper, relationship

from flix.domainmodel import model

metadata = MetaData()

users = Table(
    'users', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('username', String(255), unique=True, nullable=False),
    Column('password', String(255), nullable=False)
)

reviews = Table(
    'reviews', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('user_id', ForeignKey('users.id')),
    Column('movie_id', ForeignKey('movies.id')),
    Column('comment', String(1024), nullable=False),
    Column('timestamp', DateTime, nullable=False)
)

movies = Table(
    'movies', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('title', String(255), nullable=False),
    Column('year', Integer, nullable=False)
)

genres = Table(
    'genres', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('name', String(64), nullable=False)
)

actors = Table(
    'actors', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('name', String(64), nullable=False)
)

movie_genre = Table(
    'movie_genre', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('movie_id', ForeignKey('movies.id')),
    Column('genre_id', ForeignKey('genres.id'))
)

movie_actor = Table(
    'movie_actor', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('movie_id', ForeignKey('movies.id')),
    Column('actor_id', ForeignKey('actors.id'))
)
watchlist = Table(
    'watchlist', metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('movie_id', ForeignKey('movies.id')),
    Column('user_id', ForeignKey('users.id'))
)

def map_model_to_tables():
    mapper(model.Review, reviews, properties={
        '_comment': reviews.c.comment,
        '_timestamp': reviews.c.timestamp
    })
    movies_mapper = mapper(model.Movie, movies, properties={
         '_id': movies.c.id,
        '_title': movies.c.title,
        '_year': movies.c.year

    })
    mapper(model.User, users, properties={
        '_username': users.c.username,
        '_password': users.c.password,
        '_watchlist': relationship(
            movies_mapper,
            secondary=watchlist,
            backref="_users"
        ),
        '_comments': relationship(model.Review, backref='_user')
    })
    mapper(model.Genre, genres, properties={
        '_genre_name': genres.c.name,
        '_movie_genre': relationship(
            movies_mapper,
            secondary=movie_genre,
            backref="_genres"
        )
    })
    mapper(model.Actor, actors, properties={
        '_actor_name': actors.c.name,
        '_movie_actor': relationship(
            movies_mapper,
            secondary=movie_actor,
            backref="_actors"
        )
    })
