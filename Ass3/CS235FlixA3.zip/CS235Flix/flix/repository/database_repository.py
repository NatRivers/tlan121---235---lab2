import csv
import os

from datetime import date
from typing import List

from sqlalchemy import desc, asc
from sqlalchemy.engine import Engine
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound
from werkzeug.security import generate_password_hash

from sqlalchemy.orm import scoped_session
from flask import _app_ctx_stack

from flix.domainmodel.model import Director,Genre,Actor,Movie,Review,User, WatchList
from flix.repository.repo import AbstractRepository

genres = None
actors = None
all_movies = None
movie_id = None

class SessionContextManager:
    def __init__(self, session_factory):
        self.__session_factory = session_factory
        self.__session = scoped_session(self.__session_factory, scopefunc=_app_ctx_stack.__ident_func__)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.rollback()

    @property
    def session(self):
        return self.__session

    def commit(self):
        self.__session.commit()

    def rollback(self):
        self.__session.rollback()

    def reset_session(self):
        # this method can be used e.g. to allow Flask to start a new session for each http request,
        # via the 'before_request' callback
        self.close_current_session()
        self.__session = scoped_session(self.__session_factory, scopefunc=_app_ctx_stack.__ident_func__)

    def close_current_session(self):
        if not self.__session is None:
            self.__session.close()


class SqlAlchemyRepository(AbstractRepository):

    def __init__(self, session_factory):
        self._session_cm = SessionContextManager(session_factory)

    def close_session(self):
        self._session_cm.close_current_session()

    def reset_session(self):
        self._session_cm.reset_session()

    def add_user(self, user: User):
        with self._session_cm as scm:
            scm.session.add(user)
        scm.commit()

    def get_user(self, user_name) -> User:
        user = None
        try:
            # user = self._session_cm.session.query(User).filter_by(_username=username).one()
            user = self._session_cm.session.execute('SELECT username, password FROM users WHERE username LIKE "{}"'.format(user_name)).fetchall()

        except NoResultFound:
            # Ignore any exception and return None.
            pass
        if len(user) == 0:
            return None
        return user

    def add_movie(self, movie: Movie):
        with self._session_cm as scm:
            scm.session.add(movie)
            scm.commit()

    def get_movie(self, movie: str) -> Movie:
        mov = None

        try:
            mov = self._session_cm.session.execute('SELECT title, year FROM movies WHERE title LIKE "{}"'.format(movie)).fetchall()
            # movie = self._session_cm.session.query(Movie).filter(Movie.title == movie).one()
        except NoResultFound:
            # Ignore any exception and return None.
            pass
        return mov

    def get_number_of_movies(self):
        number_of_movies = self._session_cm.session.query(Movie).count()
        return number_of_movies

    def get_selected_movies(self, index_lst) -> List[Movie]:
        movies_chosen = list()

        # Use native SQL to retrieve article ids, since there is no mapped class for the article_tags table.
        row = self._session_cm.session.execute('SELECT * FROM movies').fetchall()

        for i in index_lst:
            movies_chosen.append(row[i][1])

        return movies_chosen

    def get_movie_for_genre(self, genre_name: str):
        movies_gen = list()

        # Use native SQL to retrieve article ids, since there is no mapped class for the article_tags table.
        row = self._session_cm.session.execute('SELECT id FROM genres WHERE name = :genre_name', {'genre_name': genre_name}).fetchone()

        if row is None:
            # No tag with the name tag_name - create an empty list.
            movies_gen = list()
        else:
            gen_id = row[0]
            # Retrieve article ids of articles associated with the tag.
            movies_gen = self._session_cm.session.execute(
                    'SELECT title FROM movies_genre WHERE gen_id = :gen_id',
                    {'gen_id': gen_id}
            ).fetchall()
            # article_ids = [id[0] for id in article_ids]

        return movies_gen

    def get_genre(self) -> List[Genre]:
        genres = self._session_cm.session.query(Genre).all()
        return genres

    def add_genre(self, gen: Genre):
        with self._session_cm as scm:
            scm.session.add(gen)
            scm.commit()

    def get_actor(self) -> Actor:
        actors = self._session_cm.session.query(Actor).all()
        return actors

    def get_review(self) -> List[Review]:
        comments = self._session_cm.session.query(Review).all()
        return comments

    def add_review(self, comment: Review):
        # super().add_review(comment)
        with self._session_cm as scm:
            scm.session.add(comment)
        scm.session.commit()

    def add_watchlst(self, username, movie):
        with self._session_cm as scm:
            scm.session.add(movie)
        scm.session.commit()

    def get_watchlst(self):
        row = self._session_cm.session.execute('SELECT * FROM watchlist').fetchall()
        return row

    def remove_from_watchlist(self, username, movie):
        with self._session_cm as scm:
            scm.session.delete(movie)
        scm.session.commit()


def read_csv_file(filename: str):
    with open(filename, mode='r', encoding='utf-8-sig') as csvfile:
        movie_file_reader = csv.reader(csvfile)

        # Read first line of the the CSV file.
        headers = next(movie_file_reader)

        # Read remaining rows from the CSV file.
        for row in movie_file_reader:
            # Strip any leading/trailing white space from data read.
            row = [item.strip() for item in row]
            yield row
    return movie_file_reader

def get_movies_by(data_path: str, chosen_dict = None):
    all_act = []
    all_gen = []
    count = 1

    file = read_csv_file(os.path.join(data_path, 'Data1000Movies.csv'))
    for row in file:
        title = row[1]
        title = title.strip()
        release_year = int(row[6])
        mov = Movie(title, release_year)
        all_movies[count] = mov

        actor = row[5]
        actor = actor.split(",")
        for a in actor:
            a = a.strip()
            if a not in all_act:
                all_act.append(a)
                actors[a] = list()
            actors[a].append(mov)

        genre = row[2]
        genre = genre.split(",")
        for g in genre:
            g = g.strip()
            if g not in all_gen:
                all_gen.append(g)
                genres[g] = list()
            genres[g].append(mov)
        count += 1

    if chosen_dict == "genre":
        return genres
    if chosen_dict == "actor":
        return actors
    if chosen_dict == "movie":
        return all_movies

def get_all_genre():
    get_gen_lst = get_movies_by("flix/datafiles", "genre")
    return get_gen_lst.keys()

def get_all_movies():
    get_all = get_movies_by("flix/datafiles", "movie")
    return get_all

def get_all_movies_titles():
    get_all = get_movies_by("flix/datafiles", "movie")
    return get_all

def get_all_actors():
    get_actors = get_movies_by("flix/datafiles", "actor")
    return get_actors.keys()

def movies_generator():
    for key, value in all_movies.items():
        yield key, value.title, value.year

def movies_genre_generator():
    movies_genre_key = 0
    gen_key = 0

    for gen in genres.keys():
        gen_key += 1
        for mov in genres[gen]:
            for key, value in all_movies.items():
                if value == mov:
                    yield movies_genre_key, key, gen_key
            movies_genre_key += 1

def movies_actor_generator():
    movies_actor_key = 0
    actor_key = 0

    for actor in actors.keys():
        actor_key += 1
        for mov in actors[actor]:
            for key, value in all_movies.items():
                if value == mov:
                    yield movies_actor_key, key, actor_key
            movies_actor_key += 1

def genre_generator():
    gen_key = 0

    for key in genres.keys():
        gen_key += 1
        yield gen_key, key

def actor_generator():
    actor_key = 0

    for key in actors.keys():
        actor_key += 1
        yield actor_key, key

def generic_generator(filename, post_process=None):
    with open(filename) as infile:
        reader = csv.reader(infile)

        # Read first line of the CSV file.
        next(reader)

        # Read remaining rows from the CSV file.
        for row in reader:
            print(row, "users")
            # Strip any leading/trailing white space from data read.
            row = [item.strip() for item in row]

            if post_process is not None:
                row = post_process(row)
            yield row

def process_user(user_row):
    user_row[2] = generate_password_hash(user_row[2])
    return user_row

def populate(engine: Engine, data_path: str):
    conn = engine.raw_connection()
    cursor = conn.cursor()

    global genres
    global actors
    global all_movies
    genres = dict()
    actors = dict()
    all_movies = dict()
    get_movies_by(data_path)

    insert_movies = """
        INSERT INTO movies (
        id, title, year)
        VALUES (?, ?, ?)"""
    cursor.executemany(insert_movies, movies_generator())

    insert_genres = """
        INSERT INTO genres (
        id, name)
        VALUES (?, ?)"""
    cursor.executemany(insert_genres, genre_generator())

    insert_actors = """
        INSERT INTO actors (
        id, name)
        VALUES (?, ?)"""
    cursor.executemany(insert_actors, actor_generator())

    insert_movie_genre = """
        INSERT INTO movie_genre (
        id, movie_id, genre_id)
        VALUES (?, ?, ?)"""
    cursor.executemany(insert_movie_genre, movies_genre_generator())

    insert_movie_actor = """
            INSERT INTO movie_actor (
            id, movie_id, actor_id)
            VALUES (?, ?, ?)"""
    cursor.executemany(insert_movie_actor, movies_actor_generator())

    insert_users = """
        INSERT INTO users (
        id, username, password)
        VALUES (?, ?, ?)"""
    cursor.executemany(insert_users, generic_generator(os.path.join(data_path, 'users.csv'), process_user))

    insert_watchlist = """
        INSERT INTO watchlist(
        id, movie_id, actor_id)
        VALUES(?, ?, ?)"""

    insert_reviews = """
        INSERT INTO reviews (
        id, user_id, movie_id, comment, timestamp)
        VALUES (?, ?, ?, ?, ?)"""
    cursor.executemany(insert_reviews, generic_generator(os.path.join(data_path, 'comments.csv')))

    conn.commit()
    conn.close()