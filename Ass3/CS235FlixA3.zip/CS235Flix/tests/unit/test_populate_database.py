from sqlalchemy import select, inspect

from flix.repository.orm import metadata

def test_database_populate_inspect_table_names(database_engine):

    # Get table information
    inspector = inspect(database_engine)
    assert inspector.get_table_names() == ['actors', 'genres', 'movie_actor', 'movie_genre', 'movies', 'reviews', 'users','watchlist']

def test_database_populate_select_all_tags(database_engine):

    # Get table information
    inspector = inspect(database_engine)
    name_of_tags_table = inspector.get_table_names()[1]

    with database_engine.connect() as connection:
        # query for records in table tags
        select_statement = select([metadata.tables[name_of_tags_table]])
        result = connection.execute(select_statement)

        all_tag_names = []
        for row in result:
            all_tag_names.append(row['name'])

        assert all_tag_names == ['Action','Adventure','Sci-Fi','Mystery','Horror','Thriller',
                                 'Animation','Comedy','Family','Fantasy','Drama','Music',
                                 'Biography','Romance','History','Crime','Western','War','Musical','Sport']

def test_database_populate_select_all_users(database_engine):

    # Get table information
    inspector = inspect(database_engine)
    name_of_users_table = inspector.get_table_names()[6]

    with database_engine.connect() as connection:
        # query for records in table users
        select_statement = select([metadata.tables[name_of_users_table]])
        result = connection.execute(select_statement)

        all_users = []
        for row in result:
            all_users.append(row['username'])

        assert all_users == ['thorke', 'fmercury', 'mjackson']

def test_database_populate_select_all_comments(database_engine):

    # Get table information
    inspector = inspect(database_engine)
    name_of_comments_table = inspector.get_table_names()[5]

    with database_engine.connect() as connection:
        # query for records in table comments
        select_statement = select([metadata.tables[name_of_comments_table]])
        result = connection.execute(select_statement)

        all_comments = []
        for row in result:
            all_comments.append((row['id'], row['user_id'], row['movie_id'], row['comment']))

        assert all_comments == [(1, 2, 862, 'THIS IS SO SAD!!! I CRIED!!!'),
                                (2, 1, 85, 'Best movie in 2015.'),
                                (3, 3, 314, 'I love the scenery of this movie.'),
                                (4, 2, 653, 'Well... not gonna sleep tonight! LOL'),
                                (5, 3, 696, 'OTW to buy a dog, and gonna name it Hachi :)'),
                                (6, 1, 982, 'Disappointed... I prefer watching Annie 2001')]

def test_database_populate_select_all_movies(database_engine):

    # Get table information
    inspector = inspect(database_engine)
    name_of_movie_table = inspector.get_table_names()[4]

    with database_engine.connect() as connection:
        # query for records in table articles
        select_statement = select([metadata.tables[name_of_movie_table]])
        result = connection.execute(select_statement)

        all_movies = []
        for row in result:
            all_movies.append((row['id'], row['title'], row['year']))


        assert all_movies[0] == (1, 'Guardians of the Galaxy', 2014)
        assert all_movies[88] == (89, 'The Hateful Eight', 2015)
        assert all_movies[999] == (1000, 'Nine Lives', 2016)