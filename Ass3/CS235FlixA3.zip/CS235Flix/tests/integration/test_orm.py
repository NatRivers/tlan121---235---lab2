import pytest

import datetime

from sqlalchemy.exc import IntegrityError

from flix.domainmodel.model import Genre, Actor, Movie, Review, User, WatchList, make_review


def insert_user(empty_session, values=None):
    new_name = "Andrew"
    new_password = "1234"

    if values is not None:
        new_name = values[0]
        new_password = values[1]

    empty_session.execute('INSERT INTO users (username, password) VALUES (:username, :password)',
                          {'username': new_name, 'password': new_password})
    row = empty_session.execute('SELECT id from users where username = :username',
                                {'username': new_name}).fetchone()
    return row[0]

def insert_users(empty_session, values):
    for value in values:
        empty_session.execute('INSERT INTO users (username, password) VALUES (:username, :password)',
                              {'username': value[0], 'password': value[1]})
    rows = list(empty_session.execute('SELECT id from users'))
    keys = tuple(row[0] for row in rows)
    return keys

def insert_movie(empty_session):
    empty_session.execute(
        'INSERT INTO movies (id, title, year) VALUES '
        '("Coronavirus: First case of virus in New Zealand" '
        '2014)'
    )
    row = empty_session.execute('SELECT id from movies').fetchone()
    return row[0]


def insert_tags(empty_session):
    empty_session.execute(
        'INSERT INTO genres (name) VALUES ("Action"), ("Music")'
    )
    rows = list(empty_session.execute('SELECT id from genres'))
    keys = tuple(row[0] for row in rows)
    return keys


def insert_article_tag_associations(empty_session, movie_key, genre_keys):
    stmt = 'INSERT INTO movie_genre (movie_id, genre_id) VALUES (:movie_id, :genre_id)'
    for gen_key in genre_keys:
        empty_session.execute(stmt, {'movie_id': movie_key, 'genre_id': gen_key})


def make_movie():
    movie = Movie("Annie", 2010)
    return movie


def make_user():
    user = User("Andrew", "111")
    return user


def test_saving_of_users_with_common_username(empty_session):
    insert_user(empty_session, ("Andrew", "1234"))
    empty_session.commit()

    with pytest.raises(IntegrityError):
        user = User("Andrew", "111")
        empty_session.add(user)
        empty_session.commit()