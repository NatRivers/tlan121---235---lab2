from datetime import date, datetime

import pytest

from flix.repository.database_repository import SqlAlchemyRepository
from flix.domainmodel.model import Genre, Actor, Movie, Review, User, WatchList, make_review
from flix.repository.repo import RepositoryException

def test_repository_can_retrieve_a_user(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    user = repo.get_user('fmercury')
    assert user[0][0] == 'fmercury'

def test_repository_does_not_retrieve_a_non_existent_user(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    user = repo.get_user('prince')
    assert user is None

def test_repository_can_retrieve_movie_count(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    number_of_articles = repo.get_number_of_movies()

    # Check that the query returned 177 Articles.
    assert number_of_articles == 1000


def test_repository_can_retrieve_movie(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    movie = repo.get_movie("Moana")

    # Check that the Article has the expected title.
    assert movie == [('Moana',2016)]

def test_repository_does_not_retrieve_a_non_existent_movie(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    movie = repo.get_movie("asdfghjk")
    assert movie == []


def test_repository_can_retrieve_comments(session_factory):
    repo = SqlAlchemyRepository(session_factory)

    assert len(repo.get_review()) == 6

